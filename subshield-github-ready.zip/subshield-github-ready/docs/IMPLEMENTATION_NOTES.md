# Implementation Notes

## Key improvements made

- Converted the loose JSX component into a complete Vite + React project.
- Fixed broken GC name references that caused `undefined` to appear in the send flow.
- Fixed directory rendering by using `gc.name` consistently.
- Added safe browser persistence helpers for localStorage.
- Persisted credentials, GC directory, activity events, and profile toggles.
- Added project-level scripts for development, production build, preview, and linting.
- Added README documentation with run instructions, testing checklist, and production notes.
- Verified the project with `npm run lint` and `npm run build`.

## Known prototype limitations

- The scan flow is a simulated front-end OCR flow.
- The send flow is simulated and does not send real email yet.
- The quote-shopping flow is simulated and does not call real carrier APIs yet.
- Documents shown in the vault are visual prototype records, not uploaded binary PDFs yet.

## Recommended next backend phase

1. Add Supabase or Firebase authentication.
2. Create policy/document/project tables.
3. Add PDF upload storage.
4. Add OCR extraction for policy type, carrier, policy number, effective date, expiration date, and endorsements.
5. Add transactional email through SendGrid, Resend, Postmark, or Gmail API.
6. Add audit logs for each document send.
