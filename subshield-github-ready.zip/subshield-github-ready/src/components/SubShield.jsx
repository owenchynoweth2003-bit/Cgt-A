import React, { useState, useEffect, useRef } from "react";
import {
  Shield, ShieldCheck, HardHat, Truck, ScrollText, FileText,
  AlertTriangle, Bell, Plus, Camera, Send, ChevronRight, Check, CheckCheck,
  Zap, TrendingDown, X, Sparkles, ScanLine, User,
  CircleDollarSign, ArrowRight, LayoutGrid, Wifi, BatteryFull,
  ShieldAlert, Umbrella, Eye, Lock, Paperclip, Mail, MapPin, Edit3,
  Folder, FilePlus, Briefcase,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  SubShield v5.1 — patched production preview                                                       */
/*  A secure vault for original carrier-issued insurance documents,    */
/*  plus a GC directory that routes the legitimate paperwork in 1 tap. */
/*  SubShield never invents documents — it stores, organizes, routes.  */
/* ------------------------------------------------------------------ */

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600;700&family=Schibsted+Grotesk:wght@500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

.ss * { box-sizing:border-box; margin:0; padding:0; -webkit-tap-highlight-color:transparent; }
.ss {
  --bg:#f6f5f2; --surf:#ffffff; --surf2:#f4f3ef; --line:#e9e7e0; --line2:#f1f0ea;
  --txt:#181a1f; --ink2:#3c4047; --muted:#73767c; --faint:#a7a9af;
  --brand:#e0991a; --brand-d:#c07d0c;
  --green:#10976a; --amber:#d6890c; --red:#e0524d;
  --shadow:0 1px 2px rgba(20,22,28,.05), 0 14px 34px -18px rgba(20,22,28,.22);
  font-family:'Hanken Grotesk',sans-serif; color:var(--txt);
  display:flex; align-items:center; justify-content:center;
  min-height:100vh; width:100%; padding:20px;
  background:radial-gradient(120% 90% at 50% -10%, #f4f3ee, #e8e7e1 70%, #e2e1da);
}
.fdisp{ font-family:'Schibsted Grotesk',sans-serif; }
.fmono{ font-family:'IBM Plex Mono',monospace; }

.phone{ position:relative; z-index:1; width:100%; max-width:404px; height:838px; max-height:92vh;
  background:var(--bg); border-radius:46px; overflow:hidden;
  box-shadow:0 0 0 10px #1c1e23, 0 0 0 11px #34373d, 0 50px 100px -34px rgba(24,26,31,.5), inset 0 1px 0 rgba(255,255,255,.6);
  display:flex; flex-direction:column; }
.statusbar{ display:flex; justify-content:space-between; align-items:center; padding:13px 28px 4px;
  font-size:13px; font-weight:600; color:var(--txt); flex:0 0 auto; }
.statusbar .ic{ display:flex; gap:6px; align-items:center; }

.screen{ flex:1 1 auto; overflow-y:auto; overflow-x:hidden; position:relative; }
.screen::-webkit-scrollbar{ width:0; }

.apphead{ display:flex; align-items:center; justify-content:space-between; padding:14px 20px 8px; }
.brand{ display:flex; align-items:center; gap:10px; }
.brandmark{ width:36px; height:36px; border-radius:11px; display:grid; place-items:center;
  background:linear-gradient(155deg,#f0ab1f,var(--brand-d)); color:#1a1408;
  box-shadow:0 6px 16px -7px rgba(224,153,26,.7); }
.brandname{ font-family:'Schibsted Grotesk'; font-weight:800; font-size:20px; letter-spacing:-.5px; color:var(--txt); }
.bell{ position:relative; width:42px; height:42px; border-radius:13px; border:1px solid var(--line);
  background:var(--surf); display:grid; place-items:center; color:var(--ink2); cursor:pointer; box-shadow:var(--shadow); }
.bell .dot{ position:absolute; top:10px; right:10px; width:8px; height:8px; border-radius:99px; background:var(--red); border:2px solid var(--surf); }

.hero{ margin:8px 20px 4px; border-radius:24px; padding:24px 22px 20px; position:relative; overflow:hidden;
  background:var(--surf); border:1px solid var(--line); box-shadow:var(--shadow); }
.hero-row{ display:flex; align-items:center; gap:20px; position:relative; z-index:1; }
.ring-wrap{ position:relative; width:112px; height:112px; flex:0 0 auto; }
.ring-num{ position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; }
.ring-num .n{ font-family:'Schibsted Grotesk'; font-weight:800; font-size:36px; line-height:1; letter-spacing:-1px; }
.ring-num .lbl{ font-family:'IBM Plex Mono'; font-size:9px; letter-spacing:1.5px; color:var(--faint); text-transform:uppercase; margin-top:5px; }
.hero-info .tag{ font-family:'IBM Plex Mono'; font-size:10px; letter-spacing:1.3px; text-transform:uppercase; color:var(--brand-d); font-weight:600; }
.hero-info h1{ font-family:'Schibsted Grotesk'; font-weight:700; font-size:21px; line-height:1.08; margin:8px 0 9px; letter-spacing:-.5px; }
.hero-info p{ font-size:13px; color:var(--muted); line-height:1.5; max-width:185px; }
.pillrow{ display:flex; gap:8px; margin-top:18px; position:relative; z-index:1; flex-wrap:wrap; }
.pill{ font-size:11.5px; font-weight:600; padding:6px 11px; border-radius:99px; display:flex; align-items:center; gap:6px;
  border:1px solid var(--line); background:var(--surf2); color:var(--ink2); }
.pill .d{ width:7px; height:7px; border-radius:99px; }

.sec{ display:flex; align-items:center; justify-content:space-between; margin:26px 24px 12px; }
.sec h2{ font-family:'Schibsted Grotesk'; font-weight:700; font-size:14px; letter-spacing:-.2px; }
.sec span{ font-family:'IBM Plex Mono'; font-size:11px; color:var(--faint); font-weight:500; }

.card{ background:var(--surf); border:1px solid var(--line); border-radius:20px; margin-bottom:12px; overflow:hidden;
  transition:border-color .25s, box-shadow .25s; cursor:pointer; opacity:0; transform:translateY(10px);
  animation:rise .55s cubic-bezier(.2,.7,.2,1) forwards; box-shadow:0 1px 2px rgba(20,22,28,.04); }
.card:hover{ box-shadow:var(--shadow); }
@keyframes rise{ to{ opacity:1; transform:none; } }
.card.crit{ border-color:rgba(224,82,77,.4); box-shadow:0 1px 2px rgba(224,82,77,.08), 0 14px 30px -20px rgba(224,82,77,.45); }
.card-main{ display:flex; align-items:center; gap:14px; padding:15px 16px; }
.cicon{ width:46px; height:46px; border-radius:13px; display:grid; place-items:center; flex:0 0 auto;
  background:var(--surf2); border:1px solid var(--line); color:var(--ink2); }
.cbody{ flex:1 1 auto; min-width:0; }
.cbody .nm{ font-weight:600; font-size:14.5px; letter-spacing:-.1px; }
.cbody .meta{ font-family:'IBM Plex Mono'; font-size:10.5px; color:var(--faint); margin-top:4px; letter-spacing:-.2px; }
.cright{ display:flex; flex-direction:column; align-items:flex-end; gap:6px; flex:0 0 auto; }
.spill{ font-size:10px; font-weight:700; letter-spacing:.3px; text-transform:uppercase; padding:4px 9px; border-radius:8px; display:flex; align-items:center; gap:4px; }
.days{ font-family:'IBM Plex Mono'; font-size:11px; color:var(--muted); }
.days b{ color:var(--txt); font-weight:600; }
.vault-pill{ display:inline-flex; align-items:center; gap:4px; font-family:'IBM Plex Mono'; font-size:9px; font-weight:600; letter-spacing:.4px; text-transform:uppercase; color:var(--green); background:rgba(16,151,106,.1); padding:3px 7px; border-radius:99px; margin-top:5px; }

.expand{ overflow:hidden; max-height:0; transition:max-height .42s cubic-bezier(.2,.7,.2,1); }
.expand.open{ max-height:760px; }
.expand-in{ padding:4px 16px 16px; border-top:1px solid var(--line2); }

.tl{ margin:18px 4px 4px; }
.tl-head{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.3px; text-transform:uppercase; color:var(--faint); font-weight:600; margin-bottom:16px; }
.track{ position:relative; height:4px; border-radius:99px; background:#ecebe4; margin:0 6px; }
.track .fill{ position:absolute; left:0; top:0; bottom:0; border-radius:99px; transition:width .6s; }
.mile{ position:absolute; top:50%; transform:translate(-50%,-50%); }
.mile .dot{ width:11px; height:11px; border-radius:99px; background:#ecebe4; border:2px solid #fff; }
.mile .ml{ position:absolute; top:14px; left:50%; transform:translateX(-50%); font-family:'IBM Plex Mono'; font-size:9px; color:var(--faint); white-space:nowrap; }
.now{ position:absolute; top:50%; transform:translate(-50%,-50%); width:15px; height:15px; border-radius:99px; box-shadow:0 0 0 3px #fff; transition:left .6s; z-index:2; }
.now::after{ content:""; position:absolute; inset:5px; border-radius:99px; background:#fff; }

.cov{ margin:18px 4px 4px; }
.cov-row{ display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; }
.cov-row .lh{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.3px; text-transform:uppercase; color:var(--faint); font-weight:600; }
.cov-row .rh{ font-family:'IBM Plex Mono'; font-size:11px; color:var(--green); font-weight:600; display:flex; align-items:center; gap:5px; }
.cov-bar{ display:flex; height:10px; border-radius:99px; background:#ecebe4; overflow:hidden; margin:0 4px; box-shadow:inset 0 1px 2px rgba(20,22,28,.04); }
.cov-green{ background:linear-gradient(90deg,var(--green),#16b07e); transition:flex-basis .6s; min-width:0; }
.cov-amber{ background:repeating-linear-gradient(45deg, rgba(214,137,12,.28) 0 5px, rgba(214,137,12,.5) 5px 10px); transition:flex-basis .6s; min-width:0; }
.cov-labels{ display:flex; justify-content:space-between; margin:11px 4px 0; font-family:'IBM Plex Mono'; font-size:9px; color:var(--faint); letter-spacing:.2px; }
.cov-labels .mid{ color:var(--brand-d); font-weight:600; }

/* Vault block in expanded card */
.vault-h{ display:flex; align-items:center; justify-content:space-between; font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.3px; text-transform:uppercase; color:var(--ink2); font-weight:600; margin:22px 4px 10px; }
.vault-h .left{ display:flex; align-items:center; gap:7px; }
.vault-h .right{ font-family:'Hanken Grotesk'; font-size:10.5px; text-transform:none; letter-spacing:0; color:var(--faint); font-weight:500; }
.vault-h .right b{ color:var(--green); font-weight:600; }
.endor-h{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.3px; text-transform:uppercase; color:var(--faint); font-weight:600; margin:14px 4px 8px; display:flex; align-items:center; gap:6px; }
.attach-btn{ width:100%; padding:10px; border:1px dashed var(--line); background:transparent; border-radius:12px; color:var(--muted); font-weight:600; font-size:11.5px; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px; font-family:'Hanken Grotesk'; transition:.15s; margin-top:4px; }
.attach-btn:hover{ border-color:#cfcdc6; color:var(--ink2); background:var(--surf2); }

/* Document tile */
.doc-tile{ display:flex; align-items:center; gap:11px; padding:10px 12px; background:var(--surf); border:1px solid var(--line); border-radius:12px; margin-bottom:7px; transition:.2s; cursor:pointer; box-shadow:0 1px 2px rgba(20,22,28,.03); }
.doc-tile:hover{ border-color:#dcdacf; }
.doc-tile.endors{ background:var(--surf2); margin-left:8px; }
.doc-thumb{ width:34px; height:42px; flex:0 0 auto; background:#fff; border:1px solid #d4d2c8; border-radius:4px; position:relative; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:5px 0 4px; overflow:hidden; box-shadow:0 1px 2px rgba(20,22,28,.06); }
.doc-thumb::after{ content:""; position:absolute; top:0; right:0; width:0; height:0; border-style:solid; border-width:0 7px 7px 0; border-color:transparent #e0ddd2 transparent transparent; }
.doc-thumb .pdf-lbl{ font-family:'Schibsted Grotesk'; font-weight:800; font-size:7.5px; color:#dd3b3b; letter-spacing:.4px; line-height:1; }
.doc-tile.endors .doc-thumb .pdf-lbl{ color:#7a7f86; }
.doc-thumb .lines{ position:absolute; left:4px; right:4px; bottom:5px; display:flex; flex-direction:column; gap:1.5px; }
.doc-thumb .lines i{ height:1.5px; background:#d5d3cb; border-radius:1px; display:block; }
.doc-info{ flex:1; min-width:0; }
.doc-info .dn{ font-size:12.5px; font-weight:600; color:var(--txt); line-height:1.3; }
.doc-info .dm{ font-family:'IBM Plex Mono'; font-size:10px; color:var(--muted); margin-top:3px; line-height:1.35; display:flex; align-items:center; gap:5px; flex-wrap:wrap; }
.doc-info .dm .vchk{ color:var(--green); font-weight:600; display:inline-flex; align-items:center; gap:2px; }
.doc-eye{ color:var(--faint); flex:0 0 auto; }

.acts{ display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:24px; }
.btn{ border:none; border-radius:13px; padding:13px 12px; font-family:'Hanken Grotesk'; font-weight:600; font-size:12.5px;
  display:flex; align-items:center; justify-content:center; gap:7px; cursor:pointer; transition:transform .12s, filter .2s, background .2s; letter-spacing:-.1px; }
.btn:active{ transform:scale(.97); }
.btn.primary{ background:var(--txt); color:#fff; }
.btn.primary:hover{ filter:brightness(1.18); }
.btn.ghost{ background:var(--surf); color:var(--txt); border:1px solid var(--line); }
.btn.ghost:hover{ background:var(--surf2); }
.btn.full{ grid-column:1 / -1; }
.btn.send{ background:var(--surf); color:var(--txt); border:1px solid var(--line); }
.btn:disabled{ opacity:.55; cursor:default; }

.spin{ animation:spin 1s linear infinite; } @keyframes spin{ to{ transform:rotate(360deg);} }

.navbar{ position:absolute; left:16px; right:16px; bottom:16px; height:62px; border-radius:21px;
  background:rgba(255,255,255,.86); backdrop-filter:blur(14px); border:1px solid var(--line);
  display:flex; align-items:center; justify-content:space-around; box-shadow:0 18px 36px -18px rgba(24,26,31,.3); }
.navi{ flex:1; display:flex; flex-direction:column; align-items:center; gap:3px; color:var(--faint); cursor:pointer; font-size:9.5px; font-weight:600; transition:color .2s; }
.navi.on{ color:var(--txt); }
.navspace{ flex:1.4; }
.fab{ position:absolute; left:50%; bottom:56px; transform:translateX(-50%); width:60px; height:60px; border-radius:20px;
  background:linear-gradient(155deg,#f0ab1f,var(--brand-d)); color:#1a1408; border:4px solid var(--bg);
  display:grid; place-items:center; cursor:pointer; z-index:31; box-shadow:0 12px 26px -8px rgba(224,153,26,.7); transition:transform .15s; }
.fab:active{ transform:translateX(-50%) scale(.92); }

.scrim{ position:absolute; inset:0; background:rgba(24,26,31,.34); backdrop-filter:blur(3px); z-index:40;
  display:flex; align-items:flex-end; animation:fade .25s; }
@keyframes fade{ from{ opacity:0; } }
.sheet{ width:100%; background:var(--surf); border-radius:28px 28px 0 0; border:1px solid var(--line); border-bottom:none;
  max-height:90%; overflow-y:auto; animation:up .34s cubic-bezier(.2,.8,.2,1); box-shadow:0 -20px 50px -20px rgba(24,26,31,.25); }
.sheet::-webkit-scrollbar{ width:0; }
@keyframes up{ from{ transform:translateY(100%); } }
.grip{ width:38px; height:4px; border-radius:99px; background:var(--line); margin:12px auto 0; }
.sheet-in{ padding:8px 22px 28px; }
.sheet-h{ font-family:'Schibsted Grotesk'; font-weight:700; font-size:21px; letter-spacing:-.4px; margin:12px 0 5px; }
.sheet-sub{ font-size:13px; color:var(--muted); line-height:1.5; margin-bottom:18px; }
.xbtn{ position:absolute; top:14px; right:18px; width:32px; height:32px; border-radius:99px; background:var(--surf2);
  border:1px solid var(--line); color:var(--muted); display:grid; place-items:center; cursor:pointer; z-index:2; }

.scan{ position:absolute; inset:0; background:var(--bg); z-index:50; display:flex; flex-direction:column; animation:fade .25s; }
.scan-top{ padding:20px 22px 8px; display:flex; align-items:center; justify-content:space-between; color:var(--txt); font-weight:600; font-size:15px; }
.finder{ flex:1; margin:4px 26px 0; position:relative; display:grid; place-items:center; }
.frame{ width:100%; aspect-ratio:.74; border-radius:20px; position:relative;
  background:linear-gradient(160deg,#efeee8,#e6e4dc); overflow:hidden; border:1px solid var(--line); box-shadow:inset 0 2px 14px rgba(24,26,31,.06); }
.corner{ position:absolute; width:30px; height:30px; border:3px solid var(--brand); }
.corner.tl{ top:14px; left:14px; border-right:none; border-bottom:none; border-radius:8px 0 0 0; }
.corner.tr{ top:14px; right:14px; border-left:none; border-bottom:none; border-radius:0 8px 0 0; }
.corner.bl{ bottom:14px; left:14px; border-right:none; border-top:none; border-radius:0 0 0 8px; }
.corner.br{ bottom:14px; right:14px; border-left:none; border-top:none; border-radius:0 0 8px 0; }
.scanline{ position:absolute; left:8px; right:8px; height:2px; background:linear-gradient(90deg,transparent,var(--brand),transparent);
  box-shadow:0 0 16px 3px rgba(224,153,26,.55); animation:scanmv 1.7s ease-in-out infinite; }
@keyframes scanmv{ 0%{top:6%;} 50%{top:92%;} 100%{top:6%;} }
.doc-lines{ position:absolute; inset:40px 32px; display:flex; flex-direction:column; gap:12px; opacity:.7; }
.doc-lines i{ height:7px; border-radius:4px; background:#d9d7cf; display:block; }
.scan-cap{ text-align:center; color:var(--muted); font-size:13px; padding:22px 30px 8px; font-weight:500; }
.scan-cap b{ color:var(--brand-d); font-weight:700; }
.shutter{ margin:8px auto 28px; width:66px; height:66px; border-radius:99px; border:3px solid var(--txt); display:grid; place-items:center; cursor:pointer; }
.shutter i{ width:48px; height:48px; border-radius:99px; background:var(--txt); display:block; transition:.15s; }
.shutter:active i{ transform:scale(.85); }

.field{ background:var(--surf); border:1px solid var(--line); border-radius:14px; padding:12px 15px; margin-bottom:9px;
  opacity:0; transform:translateY(6px); animation:rise .4s forwards; box-shadow:0 1px 2px rgba(20,22,28,.03); }
.field .fl{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1px; text-transform:uppercase; color:var(--faint); font-weight:600; }
.field .fv{ font-size:14px; font-weight:500; margin-top:4px; display:flex; align-items:center; justify-content:space-between; }
.field .fv svg{ color:var(--green); }
.vault-banner{ background:rgba(16,151,106,.07); border:1px solid rgba(16,151,106,.25); border-radius:12px; padding:11px 13px; margin:6px 0 14px; display:flex; align-items:flex-start; gap:10px; }
.vault-banner .vi{ flex:0 0 auto; color:var(--green); margin-top:1px; }
.vault-banner .vt{ font-size:12px; color:var(--ink2); line-height:1.45; }
.vault-banner .vt b{ color:var(--txt); font-weight:700; }

.qrow{ background:var(--surf); border:1px solid var(--line); border-radius:16px; padding:14px; margin-bottom:10px;
  display:flex; align-items:center; gap:13px; opacity:0; transform:translateY(8px); animation:rise .45s forwards; box-shadow:0 1px 2px rgba(20,22,28,.03); transition:border-color .2s; }
.qrow:hover{ border-color:#dcdacf; }
.qlogo{ width:42px; height:42px; border-radius:12px; display:grid; place-items:center; font-family:'Schibsted Grotesk'; font-weight:800; font-size:15px; flex:0 0 auto; }
.qbody{ flex:1; min-width:0; }
.qbody .qn{ font-weight:600; font-size:14px; }
.qbody .qd{ font-size:11.5px; color:var(--muted); margin-top:2px; }
.save{ font-family:'IBM Plex Mono'; font-weight:600; font-size:13px; color:var(--green); white-space:nowrap; }
.qpick{ border:none; background:var(--txt); color:#fff; font-weight:600; font-size:12px; padding:9px 14px; border-radius:11px; cursor:pointer; white-space:nowrap; transition:filter .2s; }
.qpick:hover{ filter:brightness(1.2); } .qpick:active{ transform:scale(.96); }

.evt{ display:flex; gap:14px; padding:14px 4px; }
.evt-ic{ width:36px; height:36px; border-radius:11px; flex:0 0 auto; display:grid; place-items:center; border:1px solid var(--line); }
.evt-b{ flex:1; }
.evt-b .et{ font-size:13.5px; font-weight:500; line-height:1.4; color:var(--ink2); }
.evt-b .ett{ font-family:'IBM Plex Mono'; font-size:10.5px; color:var(--faint); margin-top:4px; }
.evt-line{ height:1px; background:var(--line2); margin-left:50px; }

.prof-top{ display:flex; align-items:center; gap:15px; padding:8px 4px 4px; }
.avatar{ width:62px; height:62px; border-radius:18px; background:linear-gradient(150deg,#fff,#f1efe8); border:1px solid var(--line);
  display:grid; place-items:center; font-family:'Schibsted Grotesk'; font-weight:800; font-size:21px; color:var(--brand-d); box-shadow:var(--shadow); }
.prow{ display:flex; align-items:center; justify-content:space-between; padding:15px 16px; background:var(--surf); border:1px solid var(--line);
  border-radius:16px; margin-bottom:9px; box-shadow:0 1px 2px rgba(20,22,28,.03); }
.prow .pl{ display:flex; align-items:center; gap:12px; font-size:14px; font-weight:500; }
.toggle{ width:44px; height:26px; border-radius:99px; background:#e4e2d9; border:1px solid var(--line); position:relative; cursor:pointer; transition:.2s; }
.toggle.on{ background:var(--green); border-color:var(--green); }
.toggle i{ position:absolute; top:2px; left:2px; width:20px; height:20px; border-radius:99px; background:#fff; transition:.2s; box-shadow:0 1px 3px rgba(0,0,0,.2); }
.toggle.on i{ left:20px; }

.toast{ position:absolute; left:18px; right:18px; bottom:94px; z-index:60; background:var(--surf); border:1px solid var(--line);
  border-radius:16px; padding:13px 15px; display:flex; align-items:center; gap:12px; box-shadow:0 20px 40px -16px rgba(24,26,31,.4);
  animation:toastin .3s cubic-bezier(.2,.8,.2,1); }
@keyframes toastin{ from{ transform:translateY(20px); opacity:0; } }
.toast .ti{ width:32px; height:32px; border-radius:10px; display:grid; place-items:center; flex:0 0 auto; }
.toast .tt{ font-size:13px; font-weight:700; }
.toast .ts{ font-size:11.5px; color:var(--muted); margin-top:1px; }

.fade-screen{ animation:fadeScreen .3s; } @keyframes fadeScreen{ from{ opacity:0; transform:translateY(6px);} }
.pad{ padding:0 20px 132px; }
.cta-bar{ display:flex; align-items:center; gap:12px; background:#fdf2ee; border:1px solid rgba(224,82,77,.28);
  border-radius:16px; padding:13px 15px; margin:14px 20px 0; cursor:pointer; transition:background .2s; }
.cta-bar:hover{ background:#fceee9; }
.cta-bar .cb{ flex:1; } .cta-bar .cb .t{ font-weight:700; font-size:13px; } .cta-bar .cb .s{ font-size:11.5px; color:var(--muted); margin-top:2px; }

/* Directory */
.dir-head{ display:flex; align-items:center; justify-content:space-between; margin:6px 24px 18px; }
.dir-head .dh-l{ font-family:'Schibsted Grotesk'; font-weight:700; font-size:14px; letter-spacing:-.2px; }
.dir-head .dh-l span{ font-family:'IBM Plex Mono'; font-size:11px; color:var(--faint); font-weight:500; margin-left:6px; }
.add-btn{ font-family:'Hanken Grotesk'; font-weight:600; font-size:12px; color:var(--txt); background:var(--surf); border:1px solid var(--line); border-radius:11px; padding:7px 11px; cursor:pointer; display:flex; align-items:center; gap:5px; box-shadow:0 1px 2px rgba(20,22,28,.03); transition:.15s; }
.add-btn:hover{ background:var(--surf2); }
.gc-row{ display:flex; align-items:center; gap:13px; padding:14px; background:var(--surf); border:1px solid var(--line); border-radius:16px; margin-bottom:10px; cursor:pointer; transition:.2s; box-shadow:0 1px 2px rgba(20,22,28,.03); opacity:0; transform:translateY(8px); animation:rise .45s forwards; }
.gc-row:hover{ border-color:#dcdacf; }
.gc-av{ width:44px; height:44px; border-radius:13px; display:grid; place-items:center; font-family:'Schibsted Grotesk'; font-weight:800; font-size:17px; flex:0 0 auto; }
.gc-body{ flex:1; min-width:0; }
.gc-name{ font-size:14.5px; font-weight:600; }
.gc-meta{ font-family:'IBM Plex Mono'; font-size:10.5px; color:var(--muted); margin-top:3px; }

/* GC detail sheet */
.gc-det-h{ display:flex; align-items:center; gap:14px; margin:6px 0 16px; }
.gc-det-h .av{ width:52px; height:52px; border-radius:14px; display:grid; place-items:center; font-family:'Schibsted Grotesk'; font-weight:800; font-size:21px; flex:0 0 auto; }
.gc-det-h .nm{ font-family:'Schibsted Grotesk'; font-weight:700; font-size:20px; letter-spacing:-.5px; }
.gc-det-h .sub{ font-size:12px; color:var(--muted); margin-top:3px; line-height:1.45; }
.info-block{ background:var(--surf2); border:1px solid var(--line); border-radius:14px; padding:12px 14px; margin-bottom:10px; }
.info-block .lab{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.2px; text-transform:uppercase; color:var(--faint); font-weight:600; margin-bottom:6px; display:flex; align-items:center; gap:6px; }
.info-block .val{ font-size:12.5px; line-height:1.5; color:var(--txt); white-space:pre-line; }
.info-block.warn{ background:#fdf6e8; border-color:rgba(214,137,12,.32); }
.info-block.warn .lab{ color:var(--brand-d); }
.proj-row{ display:flex; align-items:center; gap:12px; padding:13px 14px; background:var(--surf); border:1px solid var(--line); border-radius:14px; margin-bottom:8px; cursor:pointer; transition:.2s; }
.proj-row:hover{ border-color:var(--txt); transform:translateY(-1px); }
.proj-row .pi{ width:32px; height:32px; border-radius:9px; display:grid; place-items:center; background:var(--surf2); border:1px solid var(--line); color:var(--ink2); flex:0 0 auto; }
.proj-row .pb{ flex:1; min-width:0; }
.proj-row .pn{ font-size:13.5px; font-weight:600; }
.proj-row .pm{ font-family:'IBM Plex Mono'; font-size:10.5px; color:var(--faint); margin-top:3px; }

.new-proj{ padding:14px; background:var(--surf2); border:1px dashed var(--line); border-radius:14px; margin-bottom:8px; }
.new-proj-h{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.2px; text-transform:uppercase; color:var(--ink2); font-weight:600; margin-bottom:10px; display:flex; align-items:center; gap:6px; }
.new-proj input{ width:100%; border:1px solid var(--line); background:var(--surf); padding:11px 13px; border-radius:11px; font-family:'Hanken Grotesk'; font-size:13px; color:var(--txt); outline:none; transition:.15s; }
.new-proj input:focus{ border-color:var(--txt); }
.new-proj input::placeholder{ color:var(--faint); }
.new-proj-cta{ width:100%; margin-top:8px; padding:11px; background:var(--txt); color:#fff; border:none; border-radius:11px; font-family:'Hanken Grotesk'; font-weight:600; font-size:12.5px; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px; transition:.15s; }
.new-proj-cta:disabled{ opacity:.35; cursor:default; }
.new-proj-cta:hover:not(:disabled){ filter:brightness(1.2); }

/* Cover email card */
.email-card{ background:var(--surf); border:1px solid var(--line); border-radius:14px; padding:14px 16px; margin-top:10px; box-shadow:0 1px 2px rgba(20,22,28,.03); }
.email-head{ font-family:'IBM Plex Mono'; font-size:9.5px; letter-spacing:1.2px; text-transform:uppercase; color:var(--ink2); font-weight:600; margin-bottom:10px; display:flex; align-items:center; gap:6px; }
.email-row{ font-size:12.5px; color:var(--ink2); margin-bottom:5px; display:flex; gap:8px; }
.email-row .k{ font-family:'IBM Plex Mono'; font-size:10.5px; color:var(--faint); font-weight:500; min-width:34px; }
.email-row .v{ flex:1; min-width:0; word-break:break-word; }
.email-row.subj{ font-weight:600; color:var(--txt); margin-top:6px; padding-top:8px; border-top:1px solid var(--line2); }
.email-body{ font-size:12.5px; line-height:1.55; color:var(--ink2); margin-top:10px; padding-top:10px; border-top:1px solid var(--line2); }
.email-body p{ margin-bottom:8px; }
.email-body .holder{ background:var(--surf2); border-left:2px solid var(--brand); padding:8px 12px; border-radius:0 8px 8px 0; margin:8px 0; font-family:'IBM Plex Mono'; font-size:11.5px; color:var(--txt); white-space:pre-line; }
.email-body ul{ list-style:none; padding:0; margin:6px 0; }
.email-body ul li{ padding:2px 0; font-size:12px; }
.email-body ul li::before{ content:"·  "; color:var(--brand-d); font-weight:700; }
.email-body .sig{ margin-top:14px; padding-top:8px; border-top:1px dashed var(--line2); font-size:11.5px; color:var(--muted); line-height:1.5; }
.email-body .sig b{ color:var(--txt); font-weight:600; }
`;

/* ---------- domain ---------- */
const ICONS = { gl: ShieldCheck, wc: HardHat, auto: Truck, lic: ScrollText, umb: Umbrella };
const iconFor = (cred) => ICONS[cred.type] || FileText;

const COVERAGE_LABEL = {
  gl: "General Liability",
  wc: "Workers' Compensation",
  auto: "Commercial Auto",
  umb: "Umbrella / Excess Liability",
};

const GREEN = "#10976a", AMBER = "#d6890c", RED = "#e0524d", BRAND = "#c07d0c";

const initialCreds = [
  {
    id: "gl", type: "gl", name: "General Liability", carrier: "Acme Mutual",
    policy: "GL-44827193", days: 45, premium: 1840,
    originalDoc: { filename: "GL_Acme_GL-44827193.pdf", pages: 4, verified: true, uploadedAt: "Mar 22, 2026" },
    endorsements: [
      { id: "e1", name: "Additional Insured", form: "CG 20 10", pages: 1, verified: true },
      { id: "e2", name: "Waiver of Subrogation", form: "CG 24 04", pages: 1, verified: true },
    ],
  },
  {
    id: "wc", type: "wc", name: "Workers' Compensation", carrier: "StateFund West",
    policy: "WC-90183321", days: 4, premium: 3210,
    originalDoc: { filename: "WC_StateFund_WC-90183321.pdf", pages: 3, verified: true, uploadedAt: "Jun 01, 2025" },
    endorsements: [
      { id: "e3", name: "Waiver of Subrogation", form: "WC 00 03 13", pages: 1, verified: true },
    ],
  },
  {
    id: "auto", type: "auto", name: "Commercial Auto", carrier: "Progressive Commercial",
    policy: "CA-55120984", days: 120, premium: 2460,
    originalDoc: { filename: "Auto_Progressive_CA-55120984.pdf", pages: 2, verified: true, uploadedAt: "Sep 24, 2025" },
    endorsements: [
      { id: "e4", name: "Additional Insured", form: "CA 20 48", pages: 1, verified: true },
    ],
  },
  {
    id: "lic", type: "lic", name: "Trade License", carrier: "TX Dept. of Licensing",
    policy: "TL-TILE-0099821", days: 60, premium: 295,
    originalDoc: { filename: "License_TX_TL-TILE-0099821.pdf", pages: 1, verified: true, uploadedAt: "Jan 12, 2026" },
    endorsements: [],
  },
];

const initialGCs = [
  {
    id: "turner", name: "Turner Construction", color: "#2f6fed", initial: "T",
    pmName: "Sarah Chen", complianceEmail: "bids@turner.com", portal: "TrustLayer portal",
    certHolderName: "Turner Construction Company",
    certHolderAddress: "375 Hudson Street\nNew York, NY 10014",
    specialReqs: "Requires $2M umbrella for commercial tile jobs. CG 20 10 must be primary, non-contributory.",
    projects: [
      { id: "tp1", name: "Downtown Marriott Remodel", lastSent: "2 days ago" },
      { id: "tp2", name: "Westside School District", lastSent: "3 mo ago" },
    ],
  },
  {
    id: "suffolk", name: "Suffolk", color: "#d4582f", initial: "S",
    pmName: "Marcus Patel", complianceEmail: "compliance@suffolk.com", portal: "Jones compliance",
    certHolderName: "Suffolk Construction Company, Inc.",
    certHolderAddress: "65 Allerton Street\nBoston, MA 02119",
    specialReqs: "30-day notice of cancellation required (60-day for non-payment).",
    projects: [
      { id: "sp1", name: "Seaport Tower Phase II", lastSent: "1 mo ago" },
    ],
  },
  {
    id: "dpr", name: "DPR Construction", color: "#10976a", initial: "D",
    pmName: "Lena Okafor", complianceEmail: "coi@dpr.com", portal: "myCOI inbox",
    certHolderName: "DPR Construction, A General Partnership",
    certHolderAddress: "1450 Veterans Blvd\nRedwood City, CA 94063",
    specialReqs: "",
    projects: [
      { id: "dp1", name: "Genentech Lab Buildout", lastSent: "2 wk ago" },
    ],
  },
  {
    id: "vanguard", name: "Vanguard Builders", color: "#c07d0c", initial: "V",
    pmName: "Tomás Reyes", complianceEmail: "pm@vanguard.co", portal: "Email · pm@vanguard.co",
    certHolderName: "Vanguard Builders, LLC",
    certHolderAddress: "880 W 5th Street\nAustin, TX 78703",
    specialReqs: "Local GC — wants COIs as PDF email attachments only, no portal upload.",
    projects: [
      { id: "vp1", name: "South Lamar Tile Buildout", lastSent: "5 days ago" },
    ],
  },
];

function statusOf(days) {
  if (days <= 10) return { key: "crit", label: "Critical", color: RED };
  if (days <= 30) return { key: "warn", label: "Expiring", color: AMBER };
  return { key: "ok", label: "Active", color: GREEN };
}
function health(days) {
  if (days >= 90) return 100;
  if (days >= 30) return 62 + ((days - 30) / 60) * 38;
  if (days >= 10) return 32 + ((days - 10) / 20) * 30;
  return Math.max(8, (days / 10) * 30);
}
function money(n) { return "$" + n.toLocaleString(); }

function useTween(target, dur = 750) {
  const [v, setV] = useState(target);
  const ref = useRef(target);
  useEffect(() => {
    const from = ref.current, to = target, start = performance.now();
    let raf;
    const tick = (now) => {
      const t = Math.min(1, (now - start) / dur);
      const e = 1 - Math.pow(1 - t, 3);
      setV(from + (to - from) * e);
      if (t < 1) raf = requestAnimationFrame(tick); else ref.current = to;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, dur]);
  return v;
}

/* count docs in package (originals + endorsements, excluding non-insurance) */
function packageDocCount(creds) {
  return creds.filter(c => c.type !== "lic")
    .reduce((s, c) => s + 1 + (c.endorsements?.length || 0), 0);
}

const STORAGE_KEYS = {
  creds: "subshield.creds.v1",
  gcs: "subshield.gcs.v1",
  activity: "subshield.activity.v1",
  toggles: "subshield.toggles.v1",
};

function readStored(key, fallback) {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function writeStored(key, value) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Avoid crashing the app if the browser blocks localStorage.
  }
}

/* ---------- root ---------- */
export default function SubShield() {
  const [creds, setCreds] = useState(() => readStored(STORAGE_KEYS.creds, initialCreds));
  const [gcs, setGcs] = useState(() => readStored(STORAGE_KEYS.gcs, initialGCs));
  const [view, setView] = useState("home");
  const [expanded, setExpanded] = useState("wc");
  const [renewing, setRenewing] = useState(null);
  const [scan, setScan] = useState(null);
  const [shop, setShop] = useState(null);
  const [send, setSend] = useState(null);
  const [toast, setToast] = useState(null);
  const [toggles, setToggles] = useState(() => readStored(STORAGE_KEYS.toggles, { push: true, autorenew: false, shop: true }));
  const [activity, setActivity] = useState(() => readStored(STORAGE_KEYS.activity, [
    { ic: ShieldAlert, c: RED,   t: "Workers' Comp expires in 4 days — bids will start flagging.", when: "Today · 7:02 AM" },
    { ic: Send,        c: GREEN, t: "COI package routed to Turner — Marriott Remodel (6 documents).", when: "2 days ago" },
    { ic: Bell,        c: AMBER, t: "General Liability entered its 60-day renewal window.",         when: "12 days ago" },
    { ic: CheckCheck,  c: GREEN, t: "Commercial Auto renewed in one tap — saved $310/yr.",          when: "1 mo ago" },
  ]));

  const fireToast = (icon, color, title, sub) => {
    setToast({ icon, color, title, sub });
    setTimeout(() => setToast(null), 3200);
  };
  const logEvent = (ic, c, t) => setActivity((a) => [{ ic, c, t, when: "Just now" }, ...a]);

  const rawScore = Math.round(creds.reduce((s, c) => s + health(c.days), 0) / creds.length);
  const score = useTween(rawScore);
  const critCount = creds.filter((c) => statusOf(c.days).key === "crit").length;
  const okCount = creds.filter((c) => statusOf(c.days).key === "ok").length;
  const scoreColor = rawScore >= 90 ? GREEN : rawScore >= 70 ? AMBER : RED;

  useEffect(() => writeStored(STORAGE_KEYS.creds, creds), [creds]);
  useEffect(() => writeStored(STORAGE_KEYS.gcs, gcs), [gcs]);
  useEffect(() => writeStored(STORAGE_KEYS.activity, activity), [activity]);
  useEffect(() => writeStored(STORAGE_KEYS.toggles, toggles), [toggles]);

  useEffect(() => { if (!scan) return; let t;
    if (scan.stage === "reading") t = setTimeout(() => setScan({ stage: "review" }), 1900);
    return () => clearTimeout(t);
  }, [scan]);
  useEffect(() => { if (!shop) return; let t;
    if (shop.stage === "searching") t = setTimeout(() => setShop((s) => ({ ...s, stage: "results" })), 2100);
    return () => clearTimeout(t);
  }, [shop]);
  useEffect(() => { if (!send) return; let t;
    if (send.stage === "sending") t = setTimeout(() => setSend((s) => ({ ...s, stage: "sent" })), 1600);
    return () => clearTimeout(t);
  }, [send]);

  const doRenew = (cred) => {
    setRenewing(cred.id);
    setTimeout(() => {
      setCreds((cs) => cs.map((c) => (c.id === cred.id ? { ...c, days: 365 } : c)));
      setRenewing(null);
      logEvent(CheckCheck, GREEN, `${cred.name} auto-renewed with ${cred.carrier}. You're covered for 12 months.`);
      fireToast(ShieldCheck, GREEN, "You're compliant.", `${cred.name} renewed — 365 days of coverage.`);
    }, 1500);
  };
  const doSwitch = (cred, q) => {
    setCreds((cs) => cs.map((c) => (c.id === cred.id ? { ...c, days: 365, carrier: q.n, premium: q.price } : c)));
    setShop(null);
    logEvent(TrendingDown, GREEN, `Switched ${cred.name} to ${q.n} — saving ${money(cred.premium - q.price)}/yr, same coverage.`);
    fireToast(TrendingDown, GREEN, `Saving ${money(cred.premium - q.price)}/yr`, `${cred.name} moved to ${q.n}.`);
  };

  /* SEND flow: pick → detail → package → sending → sent */
  const openSendFromCard = () => setSend({ stage: "pick", gc: null, project: null });
  const openSendFromDirectory = (gc) => setSend({ stage: "detail", gc, project: null });
  const pickGCInSend = (gc) => setSend((s) => ({ ...s, stage: "detail", gc }));
  const pickProject = (project) => setSend((s) => ({ ...s, stage: "package", project }));
  const confirmSend = () => setSend((s) => ({ ...s, stage: "sending" }));
  const finishSend = () => {
    const { gc, project } = send || {};
    if (!gc || !project) return;
    logEvent(Send, GREEN, `COI package routed to ${gc.name} — ${project.name} (${packageDocCount(creds)} documents).`);
    setGcs((all) => all.map((g) => {
      if (g.id !== gc.id) return g;
      const exists = g.projects.find((p) => p.id === project.id);
      const updatedProjects = exists
        ? g.projects.map((p) => p.id === project.id ? { ...p, lastSent: "Just now" } : p)
        : [{ ...project, lastSent: "Just now" }, ...g.projects];
      return { ...g, projects: updatedProjects };
    }));
    fireToast(CheckCheck, GREEN, "Package delivered.", `${gc.name} received your verified COI for ${project.name}.`);
    setSend(null);
  };

  const addScanned = () => {
    setCreds((cs) => [...cs, {
      id: "umb-" + Date.now(), type: "umb",
      name: "Umbrella / Excess Liability", carrier: "Hiscox Insurance Co.",
      policy: "UM-7740921", days: 318, premium: 980,
      originalDoc: { filename: "Umb_Hiscox_UM-7740921.pdf", pages: 3, verified: true, uploadedAt: "Today" },
      endorsements: [],
    }]);
    setScan(null);
    logEvent(Sparkles, GREEN, "Umbrella / Excess Liability vaulted from a carrier-issued document.");
    fireToast(Sparkles, GREEN, "Vaulted.", "Original Hiscox PDF is locked and tracked.");
  };

  return (
    <div className="ss">
      <style>{CSS}</style>
      <div className="phone">
        <div className="statusbar">
          <span className="fmono" style={{ fontSize: 12 }}>7:04</span>
          <div className="ic"><Wifi size={14} /><BatteryFull size={16} /></div>
        </div>

        <div className="screen">
          {view === "home" && (
            <HomeScreen creds={creds} score={score} scoreColor={scoreColor}
              critCount={critCount} okCount={okCount}
              expanded={expanded} setExpanded={setExpanded}
              renewing={renewing} doRenew={doRenew}
              openShop={(c) => setShop({ cred: c, stage: "searching" })}
              openSend={openSendFromCard}
              goActivity={() => setView("activity")} />
          )}
          {view === "directory" && <DirectoryScreen gcs={gcs} onOpenGC={openSendFromDirectory} totalDocs={packageDocCount(creds)} />}
          {view === "activity" && <ActivityScreen activity={activity} />}
          {view === "profile" && <ProfileScreen toggles={toggles} setToggles={setToggles} okCount={okCount} total={creds.length} />}
        </div>

        <div className="navbar">
          <NavItem icon={LayoutGrid} label="Home" on={view === "home"} onClick={() => setView("home")} />
          <NavItem icon={Folder} label="Directory" on={view === "directory"} onClick={() => setView("directory")} />
          <div className="navspace" />
          <NavItem icon={Bell} label="Activity" on={view === "activity"} onClick={() => setView("activity")} />
          <NavItem icon={User} label="Profile" on={view === "profile"} onClick={() => setView("profile")} />
        </div>
        <button className="fab" onClick={() => setScan({ stage: "align" })}><Camera size={25} /></button>

        {/* SCAN */}
        {scan && (
          <div className="scan">
            <div className="scan-top">
              <span>Vault a document</span>
              <button className="xbtn" style={{ position: "static" }} onClick={() => setScan(null)}><X size={16} /></button>
            </div>
            {scan.stage !== "review" ? (
              <>
                <div className="finder">
                  <div className="frame">
                    <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
                    <div className="doc-lines">
                      <i style={{ width: "55%" }} /><i style={{ width: "85%" }} /><i style={{ width: "70%" }} /><i style={{ width: "90%" }} /><i style={{ width: "40%" }} /><i style={{ width: "78%" }} />
                    </div>
                    {scan.stage === "reading" && <div className="scanline" />}
                  </div>
                </div>
                <div className="scan-cap">
                  {scan.stage === "align"
                    ? "Frame your carrier-issued certificate. We'll vault the original."
                    : <><b>Reading…</b> extracting metadata; original stays untouched.</>}
                </div>
                {scan.stage === "align"
                  ? <div className="shutter" onClick={() => setScan({ stage: "reading" })}><i /></div>
                  : <div style={{ textAlign: "center", padding: "0 0 32px", color: BRAND }}><ScanLine size={26} className="spin" /></div>}
              </>
            ) : (
              <div style={{ padding: "10px 24px 24px", overflowY: "auto" }}>
                <div className="vault-banner">
                  <Lock size={16} className="vi" />
                  <div className="vt"><b>Original locked in vault.</b> SubShield never edits or regenerates your carrier document. We only read metadata to power your dashboard.</div>
                </div>
                {[
                  ["Document type", "Umbrella / Excess Liability"],
                  ["Carrier", "Hiscox Insurance Co."],
                  ["Policy number", "UM-7740921"],
                  ["Effective", "06 / 01 / 2026"],
                  ["Expiration", "04 / 15 / 2027"],
                ].map((f, i) => (
                  <div className="field" key={f[0]} style={{ animationDelay: `${i * 90}ms` }}>
                    <div className="fl">{f[0]}</div>
                    <div className="fv">{f[1]} <Check size={15} /></div>
                  </div>
                ))}
                <button className="btn primary full" style={{ marginTop: 16, padding: 15 }} onClick={addScanned}>
                  <Lock size={16} /> Vault & track this policy
                </button>
              </div>
            )}
          </div>
        )}

        {/* SHOP */}
        {shop && (
          <div className="scrim" onClick={() => shop.stage === "results" && setShop(null)}>
            <div className="sheet" onClick={(e) => e.stopPropagation()}>
              <div className="grip" />
              <div className="sheet-in" style={{ position: "relative" }}>
                <button className="xbtn" onClick={() => setShop(null)}><X size={16} /></button>
                <div className="sheet-h">Lower my bill</div>
                <div className="sheet-sub">We packaged your {shop.cred.name} coverage and shopped it across A-rated digital carriers — same limits, same coverage.</div>
                {shop.stage === "searching" ? (
                  <div style={{ textAlign: "center", padding: "30px 0 40px", color: BRAND }}>
                    <CircleDollarSign size={30} className="spin" />
                    <div style={{ color: "var(--muted)", fontSize: 13, marginTop: 16, fontWeight: 500 }}>
                      Checking 5 carriers against your {money(shop.cred.premium)}/yr premium…
                    </div>
                  </div>
                ) : (
                  <>
                    {[
                      { n: "NEXT Insurance", c: "#10976a", i: "N", price: shop.cred.premium - 520 },
                      { n: "Thimble",        c: "#2f6fed", i: "T", price: shop.cred.premium - 360 },
                      { n: "Hiscox",         c: "#8a5fc4", i: "H", price: shop.cred.premium - 245 },
                    ].map((q, i) => (
                      <div className="qrow" key={q.n} style={{ animationDelay: `${i * 80}ms` }}>
                        <div className="qlogo" style={{ background: q.c + "18", color: q.c }}>{q.i}</div>
                        <div className="qbody">
                          <div className="qn">{q.n}</div>
                          <div className="qd">{money(q.price)}/yr · same coverage</div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div className="save">−{money(shop.cred.premium - q.price)}</div>
                          <button className="qpick" style={{ marginTop: 6 }} onClick={() => doSwitch(shop.cred, q)}>Switch</button>
                        </div>
                      </div>
                    ))}
                    <div style={{ fontSize: 11.5, color: "var(--faint)", textAlign: "center", marginTop: 10 }}>
                      SubShield earns a broker commission — you pay nothing extra.
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* SEND */}
        {send && (
          <div className="scrim" onClick={() => send.stage === "pick" && setSend(null)}>
            <div className="sheet" onClick={(e) => e.stopPropagation()}>
              <div className="grip" />
              <div className="sheet-in" style={{ position: "relative" }}>

                {send.stage === "pick" && (
                  <SendPickGC gcs={gcs} onPick={pickGCInSend} onClose={() => setSend(null)} />
                )}

                {send.stage === "detail" && (
                  <GCDetailStep gc={send.gc} onClose={() => setSend(null)}
                    onProject={pickProject}
                    onBack={() => setSend((s) => ({ ...s, stage: "pick" }))} />
                )}

                {send.stage === "package" && (
                  <PackageReview creds={creds} gc={send.gc} project={send.project}
                    onConfirm={confirmSend}
                    onBack={() => setSend((s) => ({ ...s, stage: "detail" }))}
                    onClose={() => setSend(null)} />
                )}

                {send.stage === "sending" && (
                  <div style={{ textAlign: "center", padding: "44px 0 50px", color: BRAND }}>
                    <Send size={28} className="spin" />
                    <div style={{ color: "var(--muted)", fontSize: 13, marginTop: 18, fontWeight: 500 }}>
                      Routing {packageDocCount(creds)} verified documents to {send.gc.name}…
                    </div>
                  </div>
                )}
                {send.stage === "sent" && (
                  <div style={{ textAlign: "center", padding: "34px 10px 26px" }}>
                    <div style={{ width: 72, height: 72, borderRadius: 99, background: "rgba(16,151,106,.12)", border: "1px solid rgba(16,151,106,.35)", display: "grid", placeItems: "center", margin: "0 auto 18px" }}>
                      <CheckCheck size={34} color={GREEN} />
                    </div>
                    <div className="sheet-h" style={{ textAlign: "center" }}>Package delivered</div>
                    <div className="sheet-sub" style={{ textAlign: "center" }}>
                      {send.gc.name} received your original carrier documents for <b style={{color:"var(--txt)"}}>{send.project.name}</b>. The project is saved in your directory for 1-tap re-sends.
                    </div>
                    <button className="btn primary full" style={{ padding: 15 }} onClick={finishSend}>Done</button>
                  </div>
                )}

              </div>
            </div>
          </div>
        )}

        {toast && (
          <div className="toast">
            <div className="ti" style={{ background: toast.color + "1c", color: toast.color }}><toast.icon size={17} /></div>
            <div><div className="tt">{toast.title}</div><div className="ts">{toast.sub}</div></div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- screens ---------- */
function HomeScreen({ creds, score, scoreColor, critCount, okCount, expanded, setExpanded, renewing, doRenew, openShop, openSend, goActivity }) {
  const R = 50, C = 2 * Math.PI * R;
  return (
    <div className="fade-screen">
      <div className="apphead">
        <div className="brand">
          <div className="brandmark"><Shield size={20} strokeWidth={2.4} /></div>
          <div className="brandname">SubShield</div>
        </div>
        <div className="bell" onClick={goActivity}><Bell size={18} /><span className="dot" /></div>
      </div>

      <div className="hero">
        <div className="hero-row">
          <div className="ring-wrap">
            <svg width="112" height="112" viewBox="0 0 112 112">
              <circle cx="56" cy="56" r={R} fill="none" stroke="#ecebe4" strokeWidth="8" />
              <circle cx="56" cy="56" r={R} fill="none" stroke={scoreColor} strokeWidth="8" strokeLinecap="round"
                strokeDasharray={C} strokeDashoffset={C * (1 - score / 100)} transform="rotate(-90 56 56)" style={{ transition: "stroke .4s" }} />
            </svg>
            <div className="ring-num"><div className="n" style={{ color: scoreColor }}>{Math.round(score)}</div><div className="lbl">Compliance</div></div>
          </div>
          <div className="hero-info">
            <div className="tag">{critCount ? "Action needed" : "Job-site ready"}</div>
            <h1>{critCount ? "1 credential is about to lapse" : "You are cleared to work"}</h1>
            <p>{critCount ? "Renew before it expires or GCs will start blocking your bids and gate access." : "Every certificate is current. Keep it that way."}</p>
          </div>
        </div>
        <div className="pillrow">
          <span className="pill"><span className="d" style={{ background: GREEN }} />{okCount} vaulted</span>
          {critCount > 0 && <span className="pill"><span className="d" style={{ background: RED }} />{critCount} critical</span>}
          <span className="pill"><span className="d" style={{ background: AMBER }} />Auto-renew off</span>
        </div>
      </div>

      {critCount > 0 && (
        <div className="cta-bar" onClick={() => setExpanded("wc")}>
          <AlertTriangle size={20} color={RED} />
          <div className="cb"><div className="t">Fix Workers' Comp now</div><div className="s">4 days until it blocks your next job</div></div>
          <ArrowRight size={18} color={RED} />
        </div>
      )}

      <div className="sec"><h2>My vault</h2><span>{creds.length} documents tracked</span></div>
      <div className="pad">
        {creds.map((c, i) => (
          <CredCard key={c.id} cred={c} idx={i} open={expanded === c.id}
            onToggle={() => setExpanded(expanded === c.id ? null : c.id)}
            renewing={renewing === c.id} onRenew={() => doRenew(c)}
            onShop={() => openShop(c)} onSend={openSend} />
        ))}
      </div>
    </div>
  );
}

function CredCard({ cred, idx, open, onToggle, renewing, onRenew, onShop, onSend }) {
  const st = statusOf(cred.days);
  const Icon = iconFor(cred);
  const isLongHorizon = cred.days > 120;
  const pct = Math.max(2, Math.min(100, (cred.days / 120) * 100));
  return (
    <div className={"card" + (st.key === "crit" ? " crit" : "")} style={{ animationDelay: `${idx * 70}ms` }}>
      <div className="card-main" onClick={onToggle}>
        <div className="cicon" style={st.key === "crit" ? { borderColor: "rgba(224,82,77,.35)", color: RED, background: "#fdf2ee" } : {}}><Icon size={22} /></div>
        <div className="cbody">
          <div className="nm">{cred.name}</div>
          <div className="meta">{cred.carrier} · {cred.policy}</div>
        </div>
        <div className="cright">
          <span className="spill" style={{ background: st.color + "16", color: st.color }}>
            {st.key === "crit" && <AlertTriangle size={11} />}{st.label}
          </span>
          <span className="days">{cred.days >= 365 ? <b>365 d left</b> : <><b>{cred.days}</b> d left</>}</span>
        </div>
      </div>

      <div className={"expand" + (open ? " open" : "")}>
        <div className="expand-in">
          {isLongHorizon ? (
            <div className="cov">
              <div className="cov-row">
                <span className="lh">Coverage period</span>
                <span className="rh"><CheckCheck size={12} /> Active · {cred.days} d remaining</span>
              </div>
              <div className="cov-bar">
                <div className="cov-green" style={{ flexBasis: ((cred.days - 60) / cred.days) * 100 + "%" }} />
                <div className="cov-amber" style={{ flexBasis: (60 / cred.days) * 100 + "%" }} />
              </div>
              <div className="cov-labels">
                <span>Today</span>
                <span className="mid">Renewal opens · {cred.days - 60} d</span>
                <span>Expires · {cred.days} d</span>
              </div>
              <div className="fmono" style={{ fontSize: 10.5, color: "var(--faint)", marginTop: 16, display: "flex", justifyContent: "space-between" }}>
                <span>Premium: {money(cred.premium)}/yr</span>
                <span style={{ color: "var(--green)" }}>Compliant ✓</span>
              </div>
            </div>
          ) : (
            <div className="tl">
              <div className="tl-head">Renewal timeline</div>
              <div className="track">
                <div className="fill" style={{ width: pct + "%", background: st.color }} />
                {[[60, "60d"], [30, "30d"], [10, "10d"]].map(([d, l]) => (
                  <div className="mile" key={d} style={{ left: (d / 120) * 100 + "%" }}>
                    <div className="dot" style={cred.days <= d ? { background: st.color } : {}} />
                    <div className="ml">{l}</div>
                  </div>
                ))}
                <div className="now" style={{ left: pct + "%", background: st.color }} />
              </div>
              <div className="fmono" style={{ fontSize: 10.5, color: "var(--faint)", marginTop: 22, display: "flex", justifyContent: "space-between" }}>
                <span>Premium: {money(cred.premium)}/yr</span>
                <span>Expires in {cred.days} days</span>
              </div>
            </div>
          )}

          {/* VAULT BLOCK */}
          <div className="vault-h">
            <span className="left"><Lock size={11} /> Vaulted original</span>
            <span className="right"><b>✓ Verified</b> · {cred.originalDoc.uploadedAt}</span>
          </div>
          <DocTile doc={cred.originalDoc} kind="original" carrier={cred.carrier} policy={cred.policy} />

          {cred.endorsements && cred.endorsements.length > 0 && (
            <>
              <div className="endor-h"><Paperclip size={10} /> Stapled endorsements ({cred.endorsements.length})</div>
              {cred.endorsements.map((e) => (
                <DocTile key={e.id} doc={e} kind="endorsement" />
              ))}
            </>
          )}
          <button className="attach-btn"><Plus size={13} /> Attach endorsement</button>

          <div className="acts">
            <button className="btn primary" disabled={renewing} onClick={onRenew}>
              {renewing ? <><ScanLine size={15} className="spin" /> Renewing…</> : <><Zap size={15} /> Keep me compliant</>}
            </button>
            <button className="btn ghost" onClick={onShop}><TrendingDown size={15} /> Lower my bill</button>
            <button className="btn send full" onClick={onSend}><Send size={15} /> Route to a GC</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function DocTile({ doc, kind, carrier, policy, onClick }) {
  const isEndors = kind === "endorsement";
  return (
    <div className={"doc-tile" + (isEndors ? " endors" : "")} onClick={onClick}>
      <div className="doc-thumb">
        <span className="pdf-lbl">PDF</span>
        <div className="lines">
          <i style={{ width: "70%" }} /><i style={{ width: "90%" }} /><i style={{ width: "55%" }} /><i style={{ width: "80%" }} />
        </div>
      </div>
      <div className="doc-info">
        <div className="dn">{isEndors ? `${doc.name} (${doc.form})` : doc.filename}</div>
        <div className="dm">
          {isEndors
            ? <>Stapled · {doc.pages} pg <span className="vchk"><Check size={9}/> verified</span></>
            : <>{carrier} · {policy} · {doc.pages} pages <span className="vchk"><Check size={9}/> carrier-issued</span></>}
        </div>
      </div>
      <Eye size={15} className="doc-eye" />
    </div>
  );
}

/* ---------- Directory tab ---------- */
function DirectoryScreen({ gcs, onOpenGC, totalDocs }) {
  return (
    <div className="fade-screen">
      <div className="apphead">
        <div className="brandname" style={{ fontSize: 21 }}>Directory</div>
        <div className="bell" style={{ width: "auto", padding: "0 12px", fontFamily: "'IBM Plex Mono'", fontSize: 11, color: "var(--faint)" }}>
          {totalDocs} docs ready
        </div>
      </div>
      <div className="dir-head">
        <div className="dh-l">My GCs <span>{gcs.length} saved</span></div>
        <button className="add-btn"><Plus size={13} /> Add GC</button>
      </div>
      <div className="pad" style={{ padding: "0 20px 132px" }}>
        {gcs.map((gc, i) => (
          <div className="gc-row" key={gc.id} style={{ animationDelay: `${i * 60}ms` }} onClick={() => onOpenGC(gc)}>
            <div className="gc-av" style={{ background: gc.color + "18", color: gc.color }}>{gc.initial}</div>
            <div className="gc-body">
              <div className="gc-name">{gc.name}</div>
              <div className="gc-meta">{gc.projects.length} project{gc.projects.length === 1 ? "" : "s"} · last sent {gc.projects[0]?.lastSent || "—"}</div>
            </div>
            <ChevronRight size={18} color="var(--faint)" />
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Send: pick GC ---------- */
function SendPickGC({ gcs, onPick, onClose }) {
  return (
    <>
      <button className="xbtn" onClick={onClose}><X size={16} /></button>
      <div className="sheet-h">Route COI to a GC</div>
      <div className="sheet-sub">Pick a saved GC from your directory. SubShield will package the original carrier documents and send them to their compliance portal.</div>
      {gcs.map((gc, i) => (
        <div className="qrow" key={gc.id} style={{ animationDelay: `${i * 60}ms`, cursor: "pointer" }} onClick={() => onPick(gc)}>
          <div className="qlogo" style={{ background: gc.color + "18", color: gc.color }}>{gc.initial}</div>
          <div className="qbody"><div className="qn">{gc.name || gc.name}</div><div className="qd">{gc.projects.length} project{gc.projects.length === 1 ? "" : "s"} · {gc.portal}</div></div>
          <ChevronRight size={18} color="var(--faint)" />
        </div>
      ))}
    </>
  );
}

/* ---------- Send: GC detail ---------- */
function GCDetailStep({ gc, onProject, onBack, onClose }) {
  const [newName, setNewName] = useState("");
  const submitNew = () => {
    if (!newName.trim()) return;
    onProject({ id: "p-" + Date.now(), name: newName.trim(), lastSent: "Just now", isNew: true });
  };
  return (
    <>
      <button className="xbtn" onClick={onClose}><X size={16} /></button>

      <div className="gc-det-h">
        <div className="av" style={{ background: gc.color + "18", color: gc.color }}>{gc.initial}</div>
        <div>
          <div className="nm">{gc.name}</div>
          <div className="sub">{gc.pmName} · {gc.complianceEmail}<br/>Delivered via {gc.portal}</div>
        </div>
      </div>

      {gc.specialReqs && (
        <div className="info-block warn">
          <div className="lab"><AlertTriangle size={11} /> Special requirements</div>
          <div className="val">{gc.specialReqs}</div>
        </div>
      )}

      <div className="info-block">
        <div className="lab" style={{justifyContent:"space-between", display:"flex"}}>
          <span style={{display:"flex", alignItems:"center", gap:6}}><MapPin size={11} /> Certificate Holder (locked from past COIs)</span>
          <Edit3 size={11} color="var(--faint)" style={{cursor:"pointer"}} />
        </div>
        <div className="val">{gc.certHolderName}{"\n"}{gc.certHolderAddress}</div>
      </div>

      <div style={{ fontFamily:"'IBM Plex Mono'", fontSize:9.5, letterSpacing:1.2, textTransform:"uppercase", color:"var(--faint)", fontWeight:600, margin:"18px 4px 10px", display:"flex", alignItems:"center", gap:6 }}>
        <Briefcase size={11} /> Projects — tap to send
      </div>

      {gc.projects.map((p) => (
        <div className="proj-row" key={p.id} onClick={() => onProject(p)}>
          <div className="pi"><Folder size={16} /></div>
          <div className="pb">
            <div className="pn">{p.name}</div>
            <div className="pm">Last sent {p.lastSent}</div>
          </div>
          <Send size={15} color="var(--ink2)" />
        </div>
      ))}

      <div className="new-proj">
        <div className="new-proj-h"><FilePlus size={11} /> New project for {gc.name}</div>
        <input
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="e.g. Downtown Marriott Remodel"
          onKeyDown={(e) => e.key === "Enter" && submitNew()}
        />
        <button className="new-proj-cta" disabled={!newName.trim()} onClick={submitNew}>
          <Send size={13} /> Build COI package for this project
        </button>
      </div>

      <div style={{ display:"flex", gap:9, marginTop:14 }}>
        <button className="btn ghost full" onClick={onBack}>Back to GC list</button>
      </div>
    </>
  );
}

/* ---------- Send: package review ---------- */
function PackageReview({ creds, gc, project, onConfirm, onBack, onClose }) {
  const insuredCreds = creds.filter((c) => c.type !== "lic");
  const total = packageDocCount(creds);

  // build coverage summary lines for the cover email
  const coverageLines = insuredCreds.map((c) => `${COVERAGE_LABEL[c.type]} — ${c.carrier} #${c.policy}`);
  const allEndors = insuredCreds.flatMap((c) => (c.endorsements || []).map((e) => `${e.name} (${e.form})`));

  return (
    <>
      <button className="xbtn" onClick={onClose}><X size={16} /></button>
      <div style={{ display:"flex", alignItems:"center", gap:7, color: BRAND, fontFamily:"'IBM Plex Mono'", fontSize:10.5, fontWeight:600, letterSpacing:1.2, textTransform:"uppercase", margin:"4px 0 4px" }}>
        <Eye size={13} /> Package preview
      </div>
      <div className="sheet-h">{gc.name} — {project.name}</div>
      <div className="sheet-sub">
        SubShield will route <b style={{color:"var(--txt)"}}>{total} verified documents</b> straight from your vault — every file is the original issued by your carrier or licensed broker.
      </div>

      {gc.specialReqs && (
        <div className="info-block warn" style={{ marginBottom:14 }}>
          <div className="lab"><AlertTriangle size={11} /> Reminder from your directory</div>
          <div className="val">{gc.specialReqs}</div>
        </div>
      )}

      <div style={{ fontFamily:"'IBM Plex Mono'", fontSize:9.5, letterSpacing:1.2, textTransform:"uppercase", color:"var(--ink2)", fontWeight:600, margin:"4px 4px 10px", display:"flex", alignItems:"center", gap:6 }}>
        <Folder size={11} /> Documents in this package
      </div>

      {insuredCreds.map((c) => (
        <div key={c.id} style={{ marginBottom:10 }}>
          <DocTile doc={c.originalDoc} kind="original" carrier={c.carrier} policy={c.policy} />
          {(c.endorsements || []).map((e) => (
            <DocTile key={e.id} doc={e} kind="endorsement" />
          ))}
        </div>
      ))}

      <div style={{ fontFamily:"'IBM Plex Mono'", fontSize:9.5, letterSpacing:1.2, textTransform:"uppercase", color:"var(--ink2)", fontWeight:600, margin:"20px 4px 0", display:"flex", alignItems:"center", gap:6 }}>
        <Mail size={11} /> Cover message
      </div>
      <div className="email-card">
        <div className="email-row"><span className="k">To</span><span className="v">{gc.complianceEmail} ({gc.pmName})</span></div>
        <div className="email-row"><span className="k">From</span><span className="v">owen@visiontile.co · via SubShield</span></div>
        <div className="email-row subj"><span className="k">Re</span><span className="v">COI Package · Vision Tile Co. · {project.name}</span></div>
        <div className="email-body">
          <p>Hi {gc.pmName.split(" ")[0]} &amp; Compliance Team,</p>
          <p>Attached is our current certificate-of-insurance package for the <b>{project.name}</b> project. Every document is the original PDF issued by our carrier or licensed broker — nothing regenerated.</p>
          <div className="holder">{gc.certHolderName}{"\n"}{gc.certHolderAddress}</div>
          <p style={{marginTop:8, fontWeight:600, color:"var(--txt)"}}>Coverage included ({total} files):</p>
          <ul>
            {coverageLines.map((l, i) => <li key={i}>{l}</li>)}
            {allEndors.length > 0 && <li>Endorsements: {allEndors.join(", ")}</li>}
          </ul>
          <p>Reach out if anything else is required.</p>
          <div className="sig">
            <b>Owen Reilly</b> · Tile &amp; Stone Setter<br/>
            Vision Tile Co. · 1240 Industrial Pkwy, Austin TX 78744<br/>
            512-555-0148 · owen@visiontile.co
          </div>
        </div>
      </div>

      <div style={{ display:"flex", alignItems:"center", gap:11, marginTop:14, padding:"12px 14px",
        background:"rgba(16,151,106,.07)", border:"1px solid rgba(16,151,106,.25)", borderRadius:13 }}>
        <Lock size={15} color={GREEN} />
        <div style={{ flex:1, fontSize:12, lineHeight:1.45, color:"var(--ink2)" }}>
          <b style={{color:"var(--txt)"}}>Every file is the carrier-issued original.</b> SubShield does not regenerate, redact, or modify documents — we only route them.
        </div>
      </div>

      <div style={{ display:"flex", gap:8, marginTop:16 }}>
        <button className="btn ghost" style={{ flex:1 }} onClick={onBack}>Back</button>
        <button className="btn primary" style={{ flex:2 }} onClick={onConfirm}><Send size={15} /> Send package to {gc.name.split(" ")[0]}</button>
      </div>
    </>
  );
}

/* ---------- other screens ---------- */
function ActivityScreen({ activity }) {
  return (
    <div className="fade-screen">
      <div className="apphead"><div className="brandname" style={{ fontSize: 21 }}>Activity</div></div>
      <div style={{ padding: "4px 22px 132px" }}>
        {activity.map((e, i) => (
          <div key={i}>
            <div className="evt">
              <div className="evt-ic" style={{ borderColor: e.c + "44", color: e.c, background: e.c + "12" }}><e.ic size={18} /></div>
              <div className="evt-b"><div className="et">{e.t}</div><div className="ett">{e.when}</div></div>
            </div>
            {i < activity.length - 1 && <div className="evt-line" />}
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfileScreen({ toggles, setToggles, okCount, total }) {
  const tog = (k) => setToggles((t) => ({ ...t, [k]: !t[k] }));
  return (
    <div className="fade-screen">
      <div className="apphead"><div className="brandname" style={{ fontSize: 21 }}>Profile</div></div>
      <div style={{ padding: "0 20px 132px" }}>
        <div className="prof-top">
          <div className="avatar">OR</div>
          <div>
            <div className="fdisp" style={{ fontWeight: 700, fontSize: 19 }}>Owen R.</div>
            <div style={{ color: "var(--muted)", fontSize: 13, marginTop: 3 }}>Tile &amp; Stone Setter</div>
            <div className="fmono" style={{ color: "var(--faint)", fontSize: 11, marginTop: 4 }}>Vision Tile Co. · since 2024</div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, margin: "20px 0" }}>
          <StatBox big={`${okCount}/${total}`} label="Vaulted" color={GREEN} />
          <StatBox big="4" label="GCs saved" color={BRAND} />
          <StatBox big="$310" label="Saved/yr" color={GREEN} />
        </div>

        <div className="sec" style={{ margin: "8px 4px 12px" }}><h2>Protection settings</h2></div>
        <div className="prow"><div className="pl"><Bell size={18} color="var(--muted)" /> Push alerts (60 / 30 / 10 day)</div>
          <div className={"toggle" + (toggles.push ? " on" : "")} onClick={() => tog("push")}><i /></div></div>
        <div className="prow"><div className="pl"><Zap size={18} color="var(--muted)" /> Auto-renew before lapse</div>
          <div className={"toggle" + (toggles.autorenew ? " on" : "")} onClick={() => tog("autorenew")}><i /></div></div>
        <div className="prow"><div className="pl"><TrendingDown size={18} color="var(--muted)" /> Auto-shop for cheaper rates</div>
          <div className={"toggle" + (toggles.shop ? " on" : "")} onClick={() => tog("shop")}><i /></div></div>

        <div style={{ display: "flex", alignItems: "center", gap: 8, justifyContent: "center", marginTop: 26, color: "var(--faint)", fontSize: 11.5 }}>
          <Lock size={13} /> Bank-level encryption · SOC 2 in progress
        </div>
      </div>
    </div>
  );
}

function StatBox({ big, label, color }) {
  return (
    <div style={{ flex: 1, background: "var(--surf)", border: "1px solid var(--line)", borderRadius: 16, padding: "15px 10px", textAlign: "center", boxShadow: "0 1px 2px rgba(20,22,28,.03)" }}>
      <div className="fdisp" style={{ fontWeight: 800, fontSize: 20, color, letterSpacing: "-.5px" }}>{big}</div>
      <div style={{ fontSize: 10.5, color: "var(--muted)", marginTop: 4, letterSpacing: .2 }}>{label}</div>
    </div>
  );
}

function NavItem({ icon: Icon, label, on, onClick }) {
  return (
    <div className={"navi" + (on ? " on" : "")} onClick={onClick}>
      <Icon size={21} strokeWidth={on ? 2.4 : 2} /><span>{label}</span>
    </div>
  );
}
