# SubShield

SubShield is a polished React/Vite prototype for a subcontractor insurance compliance vault. It tracks carrier-issued insurance documents, renewal windows, endorsements, GC certificate-holder requirements, and a simulated COI package routing workflow.

## What this version includes

- Mobile-first app UI with a realistic phone-style preview frame
- Insurance vault with General Liability, Workers' Comp, Commercial Auto, Trade License, and Umbrella/Excess support
- Compliance health score with active/critical/expiring states
- Renewal timeline and full coverage-period display
- Vaulted original document tiles and endorsement tiles
- Simulated document scan/vault workflow
- Simulated renewal and rate-shopping flows
- GC directory with saved GCs, project lists, certificate holder data, and special requirements
- COI package preview with cover email and verified attachment list
- Simulated send flow that updates the GC project history and activity log
- Activity feed and profile/settings screen
- Local persistence using browser `localStorage`
- GitHub-ready Vite project structure

## Tech stack

- React
- Vite
- Lucide React icons
- Vanilla CSS embedded in the main component for portability
- Browser `localStorage` for prototype persistence

## Install

```bash
npm install
```

## Run locally

```bash
npm run dev
```

Open the local Vite URL, usually:

```txt
http://localhost:5173
```

## Build

```bash
npm run build
```

## Preview production build

```bash
npm run preview
```

## Lint

```bash
npm run lint
```

## Main files

```txt
index.html
package.json
vite.config.js
eslint.config.js
src/main.jsx
src/App.jsx
src/components/SubShield.jsx
src/styles/global.css
```

## Testing checklist

1. Start the app with `npm run dev`.
2. Confirm the Home/Vault screen loads without a blank page.
3. Expand Workers' Compensation.
4. Click `Renew now` and confirm the credential changes to 365 days left.
5. Go to Activity and confirm the renewal event appears.
6. Refresh the page and confirm the renewal state stayed saved.
7. Click the center camera button.
8. Complete the scan flow and vault the Umbrella / Excess Liability policy.
9. Refresh again and confirm the new policy is still saved.
10. Go to Directory.
11. Select a GC.
12. Select an existing project or create a new project.
13. Review the COI package preview.
14. Click send and confirm the delivery confirmation uses the correct GC name.
15. Click Done and confirm Activity updates.
16. Refresh and confirm the GC/project history remains saved.

## Common errors

### `Cannot find module 'lucide-react'`

Run:

```bash
npm install
```

or:

```bash
npm install lucide-react
```

### Blank screen after moving files

Make sure `src/App.jsx` imports the component correctly:

```jsx
import SubShield from "./components/SubShield.jsx";

export default function App() {
  return <SubShield />;
}
```

### Local state looks old while testing

The prototype saves state to `localStorage`. Clear site data or run this in the browser console:

```js
localStorage.clear();
location.reload();
```

## Production notes

This is a polished front-end prototype. For a real production launch, connect these flows to a backend:

- Real user authentication
- Real PDF upload/storage
- Real OCR/document parsing
- Real COI email delivery or portal integrations
- Real broker/carrier API integrations
- Audit log and permission system
- Database records for policies, endorsements, GCs, projects, package sends, and document history

Recommended backend tables:

```txt
users
companies
policies
insurance_documents
endorsements
general_contractors
projects
coi_packages
coi_package_documents
activity_events
```
